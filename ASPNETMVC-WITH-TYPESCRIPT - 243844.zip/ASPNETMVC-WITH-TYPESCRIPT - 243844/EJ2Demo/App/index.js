import { Grid, Page, Selection } from '@syncfusion/ej2-grids';
import { orderData } from './datasource';
import { DropDownList } from '@syncfusion/ej2-dropdowns';
Grid.Inject(Page, Selection);
/**
 * Local Data sample
 */
var grid = new Grid({
    dataSource: orderData,
    allowPaging: true,
    rowSelected: function (e) {
        console.log(e);
    },
    columns: [
        { field: 'OrderID', headerText: 'Order ID', width: 120, textAlign: 'Right' },
        { field: 'CustomerName', headerText: 'Customer Name', width: 150 },
        { field: 'OrderDate', headerText: 'Order Date', width: 130, format: 'yMd', textAlign: 'Right' },
        { field: 'Freight', width: 120, format: 'C2', textAlign: 'Right' },
        { field: 'ShippedDate', headerText: 'Shipped Date', width: 130, format: 'yMd', textAlign: 'Right' },
        { field: 'ShipCountry', headerText: 'Ship Country', width: 150 }
    ],
    pageSettings: { pageCount: 5 }
});
grid.appendTo('#grid');
// defined the array of data
var sportsData = ['Badminton', 'Cricket', 'Football', 'Golf', 'Tennis'];
// initialize DropDownList component
var dropDownListObject = new DropDownList({
    //set the data to dataSource property
    dataSource: sportsData,
    width: 200,
    // set placeholder to DropDownList input element
    placeholder: "Select a game"
});
// render initialized DropDownList
dropDownListObject.appendTo('#ddlelement');
